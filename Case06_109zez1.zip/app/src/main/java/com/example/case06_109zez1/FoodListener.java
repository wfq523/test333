package com.example.case06_109zez1;


import java.util.List;


public interface FoodListener {
    //成功返回信息
    void onResponse(List<FoodBean> beanlist);
    //失败返回错误字符串
    void onFail();
}
