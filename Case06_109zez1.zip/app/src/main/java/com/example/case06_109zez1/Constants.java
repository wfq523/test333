package com.example.case06_109zez1;

public class Constants {
    public static final String BASE_URL = "http://123.207.125.141/foodService/";
}
